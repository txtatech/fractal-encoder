Place the livegrid binary in the src directory and start the server.

Or

cargo build

