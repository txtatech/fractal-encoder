use actix_web::{App, HttpResponse, HttpServer, Responder};

async fn index() -> HttpResponse {
    let html_content = include_str!("static/index.html");
    HttpResponse::Ok()
        .content_type("text/html")
        .body(html_content)
}

pub struct Server {
    // struct fields and methods
}

impl Server {
    pub fn new() -> Server {
        Server { /* initialize struct fields */ }
    }

    pub async fn run(&self) -> std::io::Result<()> {
        HttpServer::new(|| {
            App::new()
                .route("/", actix_web::web::get().to(index))
                .route("/hey", actix_web::web::get().to(manual_hello))
                .route("/{filename:.*}", actix_web::web::get().to(get_file)) // Route to serve all files
        })
        .bind("127.0.0.1:8080")?
        .run()
        .await
    }
}

async fn manual_hello() -> impl Responder {
    HttpResponse::Ok().body("Hey there!")
}



async fn get_file(req: actix_web::HttpRequest) -> actix_web::Result<actix_files::NamedFile> {
    let path: std::path::PathBuf = req.match_info().query("filename").parse().unwrap();
    let file_path = format!("static/{}", path.display());

    // Determine the content type based on the file extension
    let content_type = if let Some(extension) = path.extension() {
        match extension.to_string_lossy().to_lowercase().as_ref() {
            "json" => mime::APPLICATION_JSON,
            "js" => mime::APPLICATION_JAVASCRIPT,
            "txt" => mime::TEXT_PLAIN_UTF_8,
            "svg" => mime::IMAGE_SVG,
            "ico" => mime::IMAGE_BMP,
            "css" => mime::TEXT_CSS,
            "gif" => mime::IMAGE_GIF,
            "png" => mime::IMAGE_PNG,
            _ => mime::APPLICATION_OCTET_STREAM, // Default content type for unknown file types
        }
    } else {
        mime::APPLICATION_OCTET_STREAM // Default content type if the file has no extension
    };

    Ok(actix_files::NamedFile::open(&file_path)?.set_content_type(content_type))
}

#[actix_rt::main]
async fn main() -> std::io::Result<()> {
    let server = Server::new();
    server.run().await
}

